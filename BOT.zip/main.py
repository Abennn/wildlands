import os
import asyncio
import discord
from discord.ext import commands
from discord import app_commands, Interaction
from discord.ui import Button, View
from dotenv import load_dotenv
import aiohttp
import json
import sys
import requests
import aiohttp

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')

intents = discord.Intents.all()
bot = commands.Bot(command_prefix='?', intents=intents)

@bot.event
async def on_ready():
    await bot.change_presence(status=discord.Status.online, activity=discord.Activity(type=discord.ActivityType.watching, name="on Wildlands"))
    print(f'{bot.user} has connected to Discord!')
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} commands")
    except Exception as e:
        print(f"Failed to sync commands: {e}")

class SetupButton(Button):
    def __init__(self):
        super().__init__(label="Setup", style=discord.ButtonStyle.primary)

    async def callback(self, interaction: Interaction):
        await interaction.response.send_message("Let's start the setup!", ephemeral=True)
        user_id = interaction.user.id
        user_data = {}

        questions = [
            "What's your favourite pokemon?",
            "What's your base coordinates?",
            "Anything to know about you?"
        ]

        async def ask_question(index):
            if index >= len(questions):
                # Save the data to a .txt file
                with open(f"{user_id}_info.txt", "w") as file:
                    json.dump(user_data, file)
                await interaction.followup.send("Setup complete! Your information has been saved.", ephemeral=True)
                return

            await interaction.followup.send(questions[index], ephemeral=True)

            def check(m):
                return m.author.id == user_id and m.channel == interaction.channel

            try:
                response = await bot.wait_for('message', check=check, timeout=60)
                if index == 0:
                    # Validate Pokemon name
                    async with aiohttp.ClientSession() as session:
                        async with session.get(f"https://pokeapi.co/api/v2/pokemon/{response.content.lower()}") as resp:
                            if resp.status != 200:
                                await interaction.followup.send("Please enter a valid Pokemon name.", ephemeral=True)
                                return await ask_question(index)
                user_data[questions[index]] = response.content
                await ask_question(index + 1)
            except asyncio.TimeoutError:
                await interaction.followup.send("Setup timed out. Please try again.", ephemeral=True)

        await ask_question(0)

@bot.tree.command(name="setup", description="Start the setup process")
async def setup(interaction: Interaction):
    embed = discord.Embed(title="Setup", description="Click the button below to start the setup process.")
    view = View()
    view.add_item(SetupButton())
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

@bot.tree.command(name="info", description="Get info about a user")
@app_commands.describe(user="The user you want information about")
async def info(interaction: Interaction, user: discord.User):
    try:
        # Check if user setup data exists
        if not os.path.exists(f"{user.id}_info.txt"):
            await interaction.response.send_message(f"No information found for {user.mention}. Please run the setup command.", ephemeral=True)
            return

        # Load user setup data
        with open(f"{user.id}_info.txt", "r") as file:
            user_data = json.load(file)

        favorite_pokemon = user_data.get("What's your favourite pokemon?")
        base_coordinates = user_data.get("What's your base coordinates?")
        note = user_data.get("Anything to know about you?")
        team = user_data.get("team", [])

        if favorite_pokemon is None:
            await interaction.response.send_message("No favorite Pokémon found in user's info.", ephemeral=True)
            return

        # Fetch Pokémon sprite for favorite Pokémon
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://play.pokemonshowdown.com/sprites/xyani/{favorite_pokemon.lower()}.gif") as resp:
                if resp.status == 200:
                    pokemon_sprite = resp.url
                else:
                    pokemon_sprite = None

        embed = discord.Embed(
            title=f"{user.name}'s Information",
            description=f"Here are some information about {user.name}!",
            color=discord.Color.dark_purple()
        )

        if pokemon_sprite:
            embed.set_thumbnail(url=pokemon_sprite)

        # Adding custom emojis (you can replace with your own emoji names)
        poke_emoji = "<a:dancingpokemon:1242180878352781312>"
        coord_emoji = "<a:minecraft_map:1242181537097846835>"
        note_emoji = "<:minecraft_book:1242181837946618017>"
        team_emoji = "<:masterball:1242181224554958870>"

        # Format the team data properly
        team_str = "\n".join([f"{mon['name']} (Level {mon['level']})" for mon in team])

        # Adding fields with a single line break using triple quotes
        embed.add_field(name=f"{poke_emoji} Favorite Pokémon:", value=f'''{favorite_pokemon}''', inline=False)
        embed.add_field(name=f"{coord_emoji} Base Coordinates:", value=f"{base_coordinates}", inline=False)
        embed.add_field(name=f"{note_emoji} About Me:", value=f"{note}", inline=False)
        embed.add_field(name=f"{team_emoji} Pokemon Team:", value=team_str, inline=False)  # Use the formatted team data

        # Adding dividers
        divider = "<:divider:1242180970015228076>" * 8
        embed.description += f"\n\n{divider}\n"

        await interaction.response.send_message(embed=embed)
    except FileNotFoundError:
        await interaction.response.send_message(f"No information found for {user.mention}.", ephemeral=True)

@bot.tree.command(name="team", description="Add Pokémon to your team")
@app_commands.describe(pokemon="The Pokémon to add to your team", level="The level of the Pokémon")
async def team(interaction: Interaction, pokemon: str, level: int):
    user_id = interaction.user.id
    try:
        with open(f"{user_id}_info.txt", "r") as file:
            user_data = json.load(file)
    except FileNotFoundError:
        user_data = {}

    if "team" not in user_data:
        user_data["team"] = []

    if len(user_data["team"]) >= 6:
        await interaction.response.send_message("You can't have more than 6 Pokémon in your team.", ephemeral=True)
        return

    # Validate Pokémon name
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://pokeapi.co/api/v2/pokemon/{pokemon.lower()}") as resp:
            if resp.status != 200:
                await interaction.response.send_message("Please enter a valid Pokémon name.", ephemeral=True)
                return

    user_data["team"].append({"name": pokemon, "level": level})

    # Save the updated data
    with open(f"{user_id}_info.txt", "w") as file:
        json.dump(user_data, file)

    await interaction.response.send_message(f"{pokemon} (Level {level}) has been added to your team.", ephemeral=True)

@bot.tree.command(name="teamdelete", description="Delete your Pokémon team information")
async def teamdelete(interaction: Interaction):
    user_id = interaction.user.id
    try:
        with open(f"{user_id}_info.txt", "r") as file:
            user_data = json.load(file)
        if "team" in user_data:
            del user_data["team"]
            with open(f"{user_id}_info.txt", "w") as file:
                json.dump(user_data, file)
            await interaction.response.send_message("Your Pokémon team has been deleted.", ephemeral=True)
        else:
            await interaction.response.send_message("You don't have a Pokémon team saved.", ephemeral=True)
    except FileNotFoundError:
        await interaction.response.send_message("You don't have any information saved.", ephemeral=True)


def restart_bot(): 
    os.execv(sys.executable, ['python'] + sys.argv)

@bot.command(name= 'restart')
async def restart(ctx):
    await ctx.send("Restarting bot...")
    restart_bot()

bot.run(TOKEN)
